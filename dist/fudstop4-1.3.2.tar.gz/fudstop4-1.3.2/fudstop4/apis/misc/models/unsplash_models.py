


class ImageURLS:
    def __init__(self, urls):

        self.raw = urls.get('raw')
        self.full = urls.get('full')
        self.regular = urls.get('regular')
        self.small = urls.get('small')
        self.thumbnail = urls.get('thumb')

